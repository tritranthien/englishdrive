import json
import math
import os
from pathlib import Path
import subprocess
import tempfile

from timing import caption_words, sentence_segments


def transcribe_youtube(video_id):
    import yt_dlp

    max_duration = int(os.getenv('TRANSCRIPTION_MAX_DURATION_SECONDS', '3600'))
    max_bytes = int(os.getenv('TRANSCRIPTION_MAX_AUDIO_BYTES', str(100 * 1024 * 1024)))
    url = f'https://www.youtube.com/watch?v={video_id}'
    options = {'quiet': True, 'no_warnings': True, 'noplaylist': True, 'skip_download': True,
               'socket_timeout': 20, 'retries': 2, 'js_runtimes': {'deno': {}}}
    with yt_dlp.YoutubeDL(options) as downloader:
        info = downloader.extract_info(url, download=False)
        duration = info.get('duration') or 0
        if info.get('is_live') or not math.isfinite(duration) or duration <= 0 or duration > max_duration:
            raise ValueError(f'Chỉ hỗ trợ video có sẵn, dài tối đa {max_duration // 60} phút')
        duration_ms = round(duration * 1000)
        caption_result = None
        # Human captions first, English preferred within each class.
        for tracks in (info.get('subtitles') or {}, info.get('automatic_captions') or {}):
            languages = sorted(tracks, key=lambda lang: (not lang.startswith('en'), lang))
            for language in languages:
                if language == 'live_chat' or '-orig' in language:
                    continue
                track = next((item for item in tracks[language] if item.get('ext') == 'json3'), None)
                if not track:
                    continue
                try:
                    with downloader.urlopen(track['url']) as response:
                        data = response.read(8 * 1024 * 1024 + 1)
                    if len(data) > 8 * 1024 * 1024:
                        continue
                    segments = sentence_segments(caption_words(json.loads(data).get('events', [])), duration_ms)
                    if segments:
                        caption_result = {'source': 'caption', 'languageCode': language, 'segments': segments}
                        break
                except Exception:
                    continue
            if caption_result:
                break
        if caption_result:
            return {**caption_result, 'durationMs': duration_ms, 'title': info.get('title')}

    def check_size(progress):
        if max(progress.get('downloaded_bytes') or 0, progress.get('total_bytes') or 0) > max_bytes:
            raise ValueError('Audio vượt quá giới hạn tải về')

    with tempfile.TemporaryDirectory(prefix='englishdrive-audio-') as temp:
        with yt_dlp.YoutubeDL({**options, 'skip_download': False, 'format': 'bestaudio/best',
                               'outtmpl': str(Path(temp) / 'source.%(ext)s'),
                               'max_filesize': max_bytes, 'progress_hooks': [check_size]}) as downloader:
            downloaded = downloader.extract_info(url, download=True)
            source = Path(downloader.prepare_filename(downloaded))
        if not source.is_file() or source.stat().st_size > max_bytes:
            raise ValueError('Không tải được audio trong giới hạn cho phép')
        wav = Path(temp) / 'audio.wav'
        subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-i', str(source), '-vn', '-ac', '1', '-ar', '16000', str(wav)],
                       check=True, timeout=180, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        from faster_whisper import WhisperModel
        model = WhisperModel(os.getenv('WHISPER_MODEL', 'small'), device='cpu', compute_type='int8',
                             cpu_threads=int(os.getenv('WHISPER_CPU_THREADS', '2')),
                             download_root=os.getenv('WHISPER_CACHE_DIR', '/models'))
        segments, language = model.transcribe(str(wav), word_timestamps=True, vad_filter=True, beam_size=5)
        words = [{'startMs': round(word.start * 1000), 'endMs': round(word.end * 1000), 'text': word.word}
                 for segment in segments for word in (segment.words or [])]
        result = sentence_segments(words, duration_ms)
        if not result:
            raise ValueError('Không tìm thấy lời nói trong video')
        return {'source': 'asr', 'languageCode': language.language, 'durationMs': duration_ms,
                'title': downloaded.get('title'), 'segments': result}


def run_job(video_id, connection, temp_dir):
    # Keep ffmpeg in the same process group for deadline cancellation.
    if os.name == 'posix':
        os.setsid()
    tempfile.tempdir = temp_dir
    try:
        connection.send({'result': transcribe_youtube(video_id)})
    except Exception as error:
        connection.send({'error': str(error)[:500]})
    finally:
        connection.close()
