import json
import os
from types import SimpleNamespace
import unittest
from unittest.mock import MagicMock, patch

from worker import transcribe_youtube


class TranscriptWorkerTests(unittest.TestCase):
    def test_decodes_real_pcm_audio_with_the_installed_av_version(self):
        import tempfile
        import wave
        from pathlib import Path
        from faster_whisper.audio import decode_audio
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'silence.wav'
            with wave.open(str(source), 'wb') as output:
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(16000)
                output.writeframes(b'\0' * 32000)
            audio = decode_audio(str(source))
            self.assertEqual(len(audio), 16000)
            self.assertTrue((audio == 0).all())

    def test_prefers_manual_caption_and_never_loads_asr(self):
        import yt_dlp
        download = MagicMock()
        download.extract_info.return_value = {
            'duration': 180, 'title': 'Test',
            'subtitles': {'vi': [{'ext': 'json3', 'url': 'manual'}]},
            'automatic_captions': {'en': [{'ext': 'json3', 'url': 'automatic'}]},
        }
        download.urlopen.return_value.__enter__.return_value.read.return_value = json.dumps({
            'events': [{'tStartMs': 120000, 'dDurationMs': 500, 'segs': [{'utf8': 'Hello.'}]}],
        }).encode()
        with patch.object(yt_dlp, 'YoutubeDL') as factory:
            factory.return_value.__enter__.return_value = download
            result = transcribe_youtube('BaW_jenozKc')
        self.assertEqual(result['source'], 'caption')
        self.assertEqual(result['languageCode'], 'vi')
        self.assertEqual(result['segments'][0]['startMs'], 120000)
        self.assertEqual(download.urlopen.call_args.args, ('manual',))

    def test_rejects_live_or_long_media_instead_of_silently_truncating(self):
        import yt_dlp
        for info in ({'duration': 100, 'is_live': True}, {'duration': 3601}, {'duration': None}):
            with patch.object(yt_dlp, 'YoutubeDL') as factory:
                factory.return_value.__enter__.return_value.extract_info.return_value = info
                with self.assertRaises(ValueError):
                    transcribe_youtube('BaW_jenozKc')

    def test_asr_uses_original_word_times_and_cleans_download(self):
        import yt_dlp
        import faster_whisper
        from pathlib import Path
        download = MagicMock()
        info = {'duration': 180, 'title': 'Test'}
        source_path = None

        def factory(options):
            nonlocal source_path
            manager = MagicMock()
            manager.__enter__.return_value = download
            if not options['skip_download']:
                source_path = Path(options['outtmpl'].replace('%(ext)s', 'webm'))
                source_path.write_bytes(b'audio')
                download.prepare_filename.return_value = str(source_path)
            return manager

        download.extract_info.return_value = info
        words = [SimpleNamespace(start=100.0, end=100.35, word='Hello.')]
        model = MagicMock()
        model.transcribe.return_value = ([SimpleNamespace(words=words)], SimpleNamespace(language='en'))
        with patch.object(yt_dlp, 'YoutubeDL', side_effect=factory), \
                patch('worker.subprocess.run'), \
                patch.object(faster_whisper, 'WhisperModel', return_value=model), \
                patch.dict(os.environ, {'WHISPER_CACHE_DIR': 'unused-cache'}):
            result = transcribe_youtube('BaW_jenozKc')
        self.assertEqual(result['source'], 'asr')
        self.assertEqual(result['segments'][0]['startMs'], 100000)
        self.assertEqual(result['segments'][0]['endMs'], 100350)
        self.assertFalse(source_path.exists())
        self.assertTrue(model.transcribe.call_args.kwargs['word_timestamps'])


if __name__ == '__main__':
    unittest.main()
